---
title: FAQs
description: Frequently asked questions
---

No questions for now, but if you have some then join our [Discord Server](#soon)